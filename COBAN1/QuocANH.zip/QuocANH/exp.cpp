#include <bits/stdc++.h> 
using namespace std; 
long long a,b,c;
int main()
{
    freopen("exp.inp","r",stdin);
    freopen("exp.out","w",stdout);
    cin>>a>>b>>c;
    cout<<(a-b)*c;
    return 0;
}