#include <bits/stdc++.h> 
using namespace std; 
long long a,b,c,t,n,m;
int main()
{
    freopen("NOIQUY.inp","r",stdin);
    freopen("NOIQUY.out","w",stdout);
    cin>>a>>b>>c>>t>>n>>m;
    cout<<a*t+n*b+c*m;
    return 0;
}