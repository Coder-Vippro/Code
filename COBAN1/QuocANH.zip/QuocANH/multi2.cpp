#include <bits/stdc++.h> 
using namespace std; 
long long a;
int main()
{
    freopen("multi2.inp","r",stdin);
    freopen("multi2.out","w",stdout);
    cin>>a;
    cout<<a*2;
}