#include <bits/stdc++.h> 
using namespace std; 
int main()
{
    freopen("triangle2.inp","r",stdin);
    freopen("triangle2.out","w",stdout);
  long long a, b, c;
  cin >> a >> b >> c;
  if (a*a + b*b == c*c || b*b + c*c == a*a || a*a + c*c == b*b) 
  {
    cout << "YES";
  } else {
    cout << "NO";
  }

  
}
