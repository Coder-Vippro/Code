#include <bits/stdc++.h>

using namespace std;
long long n;
int main()
{
    freopen("SHOES.inp","r",stdin);
    freopen("SHOES.out","w",stdout);
    cin>>n;
    if(n==0)cout<<0;
    else cout<<n+1;
}
