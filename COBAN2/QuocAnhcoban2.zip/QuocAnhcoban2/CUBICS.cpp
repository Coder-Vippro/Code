#include <bits/stdc++.h>

using namespace std;
long long n;
int main() 
{
  freopen("CUBICS.inp","r",stdin);
  freopen("CUBICS.out","w",stdout);
  cin >> n;
  cout<<n*(n+1)/2;
  return 0;
}