#include <bits/stdc++.h>

using namespace std;
long long n;
int main()
{
    freopen("HANDS.inp","r",stdin);
    freopen("HANDS.out","w",stdout);
    cin>>n;
    cout<<n*(n-1)/2;
}
